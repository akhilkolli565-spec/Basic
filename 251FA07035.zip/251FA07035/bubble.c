#include<stdio.h>
#include<stdbool.h>
void print(int a[],int n)
{
	int i;
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}
void bubble(int a[],int n)//function to implement bubble sort 
{
	int i,j,temp;
	bool isswapped=false;
	for(i=0;i<n;i++){
		isswapped=false;
		for(j=0;j< n-i-1;j++){
			if(a[j]>a[j+1]){
				isswapped=true;
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
		if(!isswapped){
			break;
		}
	}
}
int	 main() {
	int i,j,temp;
int a[5]={15,16,11,13,14};
int n=sizeof(a)/sizeof(a[0]);
printf("before sorting array elements are:\n");
print(a,n);
bubble(a,n);
printf("\n after sorting array element s are:\n");
print(a,n);
}