#include<stdio.h>
int main(){
	int myarray[]={24,2,11,6,3};
	int n=sizeof(myarray)/sizeof(myarray[0]);
	for(int i=1;i<n;i++){
		int insertIndex=i;
		int currentValue=my array[i];
		intj=i-1;
	while(j<=0&&myarray[j]>currentvalue){
		myarray[j+1]=myarray[j];
		insertIndex=j;
		j-;
	}
	myarray[insertIndex]=currentvalue;
	}
	printf("sorted array:");
	for (int i=0;j<n;i++){
		printf("%d",my array[i]);
	}
	return 0;
}2